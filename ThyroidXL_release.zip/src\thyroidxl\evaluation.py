from __future__ import annotations

from .metrics.classification import classification_metrics
from .metrics.segmentation import segmentation_metrics


def evaluate_segmentation(predictions, targets, threshold=0.5, spacing=(1.0, 1.0)):
    rows = [segmentation_metrics(pred, target, threshold, spacing) for pred, target in zip(predictions, targets)]
    if not rows:
        return {"dice": float("nan"), "iou": float("nan"), "hd95": float("nan"), "count": 0}
    return {key: sum(row[key] for row in rows) / len(rows) for key in ("dice", "iou", "hd95")} | {"count": len(rows)}


def evaluate_classification(scores, targets, threshold=0.5):
    return classification_metrics(scores, targets, threshold)
