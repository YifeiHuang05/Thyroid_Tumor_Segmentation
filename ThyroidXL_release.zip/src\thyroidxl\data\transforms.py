from __future__ import annotations

import random


class PairedResizePad:
    def __init__(self, size=(512, 512), fill=0):
        self.height, self.width = int(size[0]), int(size[1])
        self.fill = fill

    def __call__(self, image, mask=None):
        from PIL import Image
        ratio = min(self.width / float(image.width), self.height / float(image.height))
        new_size = (max(1, int(round(image.width * ratio))), max(1, int(round(image.height * ratio))))
        image = image.resize(new_size, Image.BILINEAR)
        canvas = Image.new(image.mode, (self.width, self.height), color=self.fill)
        offset = ((self.width - new_size[0]) // 2, (self.height - new_size[1]) // 2)
        canvas.paste(image, offset)
        image = canvas
        if mask is not None:
            mask = mask.resize(new_size, Image.NEAREST)
            mask_canvas = Image.new(mask.mode, (self.width, self.height), color=0)
            mask_canvas.paste(mask, offset)
            mask = mask_canvas
        return _to_tensor(image), _to_mask_tensor(mask) if mask is not None else None


class NativePad:
    """Keep native pixels and pad only to a model-friendly multiple.

    This transform never rescales the image.  It is intended for batch size 1
    or shape-bucketed loaders; the returned tensor dimensions are divisible by
    ``multiple`` so U-Net downsampling remains well-defined.
    """
    def __init__(self, multiple=32, fill=0):
        self.multiple = int(multiple)
        self.fill = fill

    def __call__(self, image, mask=None):
        from PIL import Image
        width, height = image.size
        padded_width = ((width + self.multiple - 1) // self.multiple) * self.multiple
        padded_height = ((height + self.multiple - 1) // self.multiple) * self.multiple
        canvas = Image.new(image.mode, (padded_width, padded_height), color=self.fill)
        canvas.paste(image, (0, 0))
        if mask is not None:
            mask_canvas = Image.new(mask.mode, (padded_width, padded_height), color=0)
            mask_canvas.paste(mask, (0, 0))
            mask = mask_canvas
        return _to_tensor(canvas), _to_mask_tensor(mask) if mask is not None else None


class PairedAugment:
    def __init__(self, horizontal_flip=False, probability=0.5, seed=None):
        self.horizontal_flip = horizontal_flip
        self.probability = probability
        self.random = random.Random(seed)

    def __call__(self, image, mask=None):
        from PIL import Image
        if self.horizontal_flip and self.random.random() < self.probability:
            image = image.transpose(Image.FLIP_LEFT_RIGHT)
            if mask is not None:
                mask = mask.transpose(Image.FLIP_LEFT_RIGHT)
        return _to_tensor(image), _to_mask_tensor(mask) if mask is not None else None


def _to_tensor(image):
    import numpy as np
    import torch
    array = np.asarray(image, dtype=np.float32) / 255.0
    if array.ndim == 2:
        array = array[None, ...]
    else:
        array = array.transpose(2, 0, 1)
    return torch.from_numpy(array.copy())


def _to_mask_tensor(mask):
    import numpy as np
    import torch
    array = (np.asarray(mask) > 0).astype(np.float32)
    return torch.from_numpy(array[None, ...].copy())
