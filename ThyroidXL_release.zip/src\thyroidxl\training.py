from __future__ import annotations

from pathlib import Path

from .data.gate import require_data_gate


def train_guard(audit_report, allow_training=False):
    """Require both an explicit flag and a completed DATA GATE."""
    if not allow_training:
        raise RuntimeError("formal training is disabled until --allow-training is supplied after DATA GATE")
    require_data_gate(audit_report)


def binary_loss(logits, targets, pos_weight=None, class_weights=None):
    import torch
    import torch.nn.functional as F
    kwargs = {}
    if pos_weight is not None:
        kwargs["pos_weight"] = pos_weight
    loss = F.binary_cross_entropy_with_logits(logits, targets.float(), reduction="none", **kwargs)
    if class_weights is not None:
        weights = torch.where(targets.long() == 0, class_weights[0], class_weights[1])
        loss = loss * weights
    return loss.mean()


def segmentation_loss(logits, targets):
    import torch
    import torch.nn.functional as F
    probabilities = torch.sigmoid(logits)
    intersection = (probabilities * targets).sum(dim=(-2, -1))
    denominator = probabilities.sum(dim=(-2, -1)) + targets.sum(dim=(-2, -1))
    dice = 1.0 - ((2 * intersection + 1e-6) / (denominator + 1e-6)).mean()
    return 0.5 * F.binary_cross_entropy_with_logits(logits, targets.float()) + 0.5 * dice


def run_epoch(model, loader, optimizer=None, task="task_a", device="cpu", pos_weight=None, class_weights=None):
    """Minimal reusable epoch loop; caller must perform DATA GATE before use."""
    import torch
    model.to(device)
    training = optimizer is not None
    model.train(training)
    total = 0.0
    count = 0
    for batch in loader:
        images = batch["image"].to(device)
        if training:
            optimizer.zero_grad()
        logits = model(images)
        if task == "task_a":
            loss = segmentation_loss(logits, batch["mask"].to(device))
        elif task == "task_c":
            loss = binary_loss(logits, batch["label"].to(device), pos_weight=pos_weight, class_weights=class_weights if training else None)
        else:
            raise ValueError("task must be task_a or task_c")
        if training:
            loss.backward()
            optimizer.step()
        total += float(loss.detach().cpu()) * len(images)
        count += len(images)
    return {"loss": total / count if count else float("nan"), "count": count}


def fit(model, train_loader, val_loader, optimizer, task="task_a", device="cpu", epochs=1, checkpoint_path=None, pos_weight=None, class_weights=None):
    """Run a caller-approved training loop and persist the best validation loss."""
    import torch
    best = float("inf")
    history = []
    for epoch in range(1, int(epochs) + 1):
        train_result = run_epoch(model, train_loader, optimizer, task, device, pos_weight=pos_weight, class_weights=class_weights)
        with torch.no_grad():
            val_result = run_epoch(model, val_loader, None, task, device) if val_loader is not None else {"loss": float("nan"), "count": 0}
        row = {"epoch": epoch, "train_loss": train_result["loss"], "val_loss": val_result["loss"]}
        history.append(row)
        if checkpoint_path and val_result["loss"] < best:
            best = val_result["loss"]
            path = Path(checkpoint_path)
            path.parent.mkdir(parents=True, exist_ok=True)
            torch.save({"model": model.state_dict(), "epoch": epoch, "history": history}, path)
    return history
