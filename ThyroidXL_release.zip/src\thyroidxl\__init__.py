"""Leakage-safe ThyroidXL utilities for Tasks A and C."""

__version__ = "0.1.0"
