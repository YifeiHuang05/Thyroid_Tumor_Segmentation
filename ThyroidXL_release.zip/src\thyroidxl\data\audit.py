from __future__ import annotations

import json
from collections import Counter
from pathlib import Path

from .manifest import DatasetManifest


def audit_manifest(root, decode_content=False):
    """Audit file layout and optionally decode image/mask headers.

    This function is safe to run before DATA GATE. It never writes to raw data.
    """
    manifest = DatasetManifest(root)
    report = {
        "root": str(Path(root)),
        "splits": {},
        "train_test_patient_overlap": manifest.train_test_patient_overlap(),
        "official_split_files": _audit_official_patient_lists(manifest),
    }
    for split in ("train", "test"):
        summary = manifest.split_summary(split)
        summary["image_mask_stem_mismatch"] = _stem_mismatch(root, split, "images", "masks")
        if decode_content:
            summary.update(_decode_summary(manifest.samples(split)))
        report["splits"][split] = summary
    report["data_gate"] = {
        "passed": False,
        "reason": "metadata/pathology and real split audit require authorized ThyroidXL content",
    }
    return report


def _audit_official_patient_lists(manifest):
    listed = manifest.official_patient_lists()
    result = {}
    for split, values in listed.items():
        image_groups = {row.patient_id for row in manifest.samples(split) if row.patient_id}
        if values is None:
            result[split] = {"present": False}
            continue
        listed_set = set(values)
        result[split] = {
            "present": True,
            "listed_patients": len(listed_set),
            "image_patients": len(image_groups),
            "listed_not_in_images": sorted(listed_set - image_groups),
            "images_not_in_list": sorted(image_groups - listed_set),
        }
    return result


def _stem_mismatch(root, split, left, right):
    left_dir = Path(root) / split / left
    right_dir = Path(root) / split / right
    left_stems = {p.stem for p in left_dir.glob("*") if p.is_file()} if left_dir.exists() else set()
    right_stems = {p.stem for p in right_dir.glob("*") if p.is_file()} if right_dir.exists() else set()
    return {"missing_right": sorted(left_stems - right_stems), "extra_right": sorted(right_stems - left_stems)}


def _decode_summary(samples):
    try:
        from PIL import Image
        import numpy as np
    except ImportError as exc:
        return {"decode_skipped": str(exc)}
    result = {"decoded_images": 0, "decoded_masks": 0, "decode_errors": [], "mask_value_counts": Counter()}
    for sample in samples:
        try:
            with Image.open(sample.image_path) as image:
                image.verify()
            result["decoded_images"] += 1
        except Exception as exc:
            result["decode_errors"].append({"image_id": sample.image_id, "kind": "image", "error": str(exc)})
        if sample.mask_path:
            try:
                with Image.open(sample.mask_path) as mask:
                    values = np.asarray(mask.convert("L"))
                    result["decoded_masks"] += 1
                    result["mask_value_counts"].update(str(int(v)) for v in np.unique(values))
            except Exception as exc:
                result["decode_errors"].append({"image_id": sample.image_id, "kind": "mask", "error": str(exc)})
    result["mask_value_counts"] = dict(result["mask_value_counts"])
    return result


def save_audit_report(report, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    return path
