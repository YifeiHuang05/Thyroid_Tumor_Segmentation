from __future__ import annotations

import math


def _array(value):
    try:
        return value.detach().cpu().numpy()
    except AttributeError:
        try:
            return value.numpy()
        except AttributeError:
            return value


def _binary(value, threshold=0.5):
    array = _array(value)
    return (array >= threshold).astype("uint8")


def dice_score(prediction, target, threshold=0.5, empty_value=1.0):
    pred = _binary(prediction, threshold)
    truth = _binary(target, threshold)
    intersection = float((pred & truth).sum())
    denominator = float(pred.sum() + truth.sum())
    return empty_value if denominator == 0 else (2.0 * intersection / denominator)


def iou_score(prediction, target, threshold=0.5, empty_value=1.0):
    pred = _binary(prediction, threshold)
    truth = _binary(target, threshold)
    union = float((pred | truth).sum())
    return empty_value if union == 0 else float((pred & truth).sum()) / union


def _boundary(mask):
    mask = mask.astype(bool)
    if mask.ndim != 2:
        raise ValueError("HD95 currently expects 2-D masks")
    try:
        from scipy.ndimage import binary_erosion
        return mask ^ binary_erosion(mask, border_value=0)
    except ImportError:
        boundary = mask.copy()
        boundary[1:-1, 1:-1] &= ~(
            mask[:-2, 1:-1] & mask[2:, 1:-1] & mask[1:-1, :-2] & mask[1:-1, 2:]
        )
        return boundary


def _direct_distances(source, destination, spacing=(1.0, 1.0)):
    points_a = [(int(y), int(x)) for y, x in zip(*source.nonzero())]
    points_b = [(int(y), int(x)) for y, x in zip(*destination.nonzero())]
    if not points_a or not points_b:
        return []
    values = []
    for ay, ax in points_a:
        values.append(min(math.sqrt(((ay - by) * spacing[0]) ** 2 + ((ax - bx) * spacing[1]) ** 2) for by, bx in points_b))
    return values


def hd95(prediction, target, threshold=0.5, spacing=(1.0, 1.0), empty_value=0.0):
    pred = _binary(prediction, threshold)
    truth = _binary(target, threshold)
    pred_boundary = _boundary(pred)
    truth_boundary = _boundary(truth)
    if not pred_boundary.any() and not truth_boundary.any():
        return float(empty_value)
    if not pred_boundary.any() or not truth_boundary.any():
        return float("inf")
    try:
        from scipy.ndimage import distance_transform_edt
        truth_distance = distance_transform_edt(~truth_boundary, sampling=spacing)
        pred_distance = distance_transform_edt(~pred_boundary, sampling=spacing)
        distances = list(truth_distance[pred_boundary]) + list(pred_distance[truth_boundary])
    except ImportError:
        distances = _direct_distances(pred_boundary, truth_boundary, spacing) + _direct_distances(truth_boundary, pred_boundary, spacing)
    distances.sort()
    index = min(len(distances) - 1, int(math.ceil(0.95 * len(distances))) - 1)
    return float(distances[index])


def segmentation_metrics(prediction, target, threshold=0.5, spacing=(1.0, 1.0)):
    return {
        "dice": dice_score(prediction, target, threshold),
        "iou": iou_score(prediction, target, threshold),
        "hd95": hd95(prediction, target, threshold, spacing),
    }
