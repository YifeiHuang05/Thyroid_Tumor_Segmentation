from __future__ import annotations

import math


def _as_list(values):
    try:
        return values.detach().cpu().numpy().tolist()
    except AttributeError:
        try:
            return values.tolist()
        except AttributeError:
            return list(values)


def _binary_predictions(scores, threshold):
    return [1 if float(value) >= threshold else 0 for value in _as_list(scores)]


def _confusion(predictions, targets):
    matrix = [[0, 0], [0, 0]]
    for predicted, target in zip(predictions, targets):
        matrix[int(target)][int(predicted)] += 1
    return matrix


def _safe_div(numerator, denominator):
    return float(numerator) / denominator if denominator else 0.0


def classification_metrics(scores, targets, threshold=0.5):
    scores = _as_list(scores)
    targets = [int(value) for value in _as_list(targets)]
    if len(scores) != len(targets):
        raise ValueError("scores and targets must have equal length")
    predictions = _binary_predictions(scores, threshold)
    cm = _confusion(predictions, targets)
    tn, fp = cm[0][0], cm[0][1]
    fn, tp = cm[1][0], cm[1][1]
    precision_pos = _safe_div(tp, tp + fp)
    recall_pos = _safe_div(tp, tp + fn)
    precision_neg = _safe_div(tn, tn + fn)
    recall_neg = _safe_div(tn, tn + fp)
    f1_pos = _safe_div(2 * precision_pos * recall_pos, precision_pos + recall_pos)
    f1_neg = _safe_div(2 * precision_neg * recall_neg, precision_neg + recall_neg)
    accuracy = _safe_div(tp + tn, len(targets))
    sensitivity = recall_pos
    specificity = recall_neg
    balanced_accuracy = (sensitivity + specificity) / 2.0
    try:
        from sklearn.metrics import average_precision_score, roc_auc_score
        auroc = float(roc_auc_score(targets, scores)) if len(set(targets)) > 1 else float("nan")
        average_precision = float(average_precision_score(targets, scores)) if any(targets) else float("nan")
    except ImportError:
        auroc = float("nan")
        average_precision = float("nan")
    return {
        "macro_f1": (f1_pos + f1_neg) / 2.0,
        "balanced_accuracy": balanced_accuracy,
        "accuracy": accuracy,
        "auroc": auroc,
        "average_precision": average_precision,
        "sensitivity": sensitivity,
        "specificity": specificity,
        "confusion_matrix": cm,
        "per_class_f1": {"0": f1_neg, "1": f1_pos},
        "threshold": float(threshold),
    }


def select_threshold(scores, targets, candidates=None):
    candidates = candidates or [i / 100.0 for i in range(1, 100)]
    scored = [(classification_metrics(scores, targets, threshold), threshold) for threshold in candidates]
    scored.sort(key=lambda item: (item[0]["macro_f1"] + item[0]["balanced_accuracy"]) / 2.0, reverse=True)
    return scored[0][1], scored[0][0]
