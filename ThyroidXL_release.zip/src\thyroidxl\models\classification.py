from __future__ import annotations


try:
    import torch
    from torch import nn
    import torch.nn.functional as F
except ImportError:  # pragma: no cover
    torch = None
    nn = None
    F = None


if nn is not None:
    class _ImageBackbone(nn.Module):
        def __init__(self, in_channels=1, feature_dim=128):
            super().__init__()
            self.features = nn.Sequential(
                nn.Conv2d(in_channels, 32, 5, stride=2, padding=2), nn.ReLU(inplace=True),
                nn.Conv2d(32, 64, 3, stride=2, padding=1), nn.BatchNorm2d(64), nn.ReLU(inplace=True),
                nn.Conv2d(64, feature_dim, 3, stride=2, padding=1), nn.BatchNorm2d(feature_dim), nn.ReLU(inplace=True),
                nn.AdaptiveAvgPool2d(1),
            )
            self.feature_dim = feature_dim

        def forward(self, value):
            return self.features(value).flatten(1)


    class FullImageClassifier(nn.Module):
        """Full-image binary baseline with optional torchvision ConvNeXt backend."""

        def __init__(self, in_channels=1, pretrained=False, backend="auto"):
            super().__init__()
            self.architecture = "convnext_tiny"
            self.backend = backend
            self._backbone = None
            feature_dim = 128
            if backend in ("auto", "torchvision"):
                try:
                    from torchvision.models import convnext_tiny, ConvNeXt_Tiny_Weights
                    weights = ConvNeXt_Tiny_Weights.DEFAULT if pretrained else None
                    model = convnext_tiny(weights=weights)
                    if in_channels != 3:
                        first = model.features[0][0]
                        replacement = nn.Conv2d(in_channels, first.out_channels, first.kernel_size, first.stride, first.padding, bias=False)
                        if weights is not None and in_channels == 1:
                            with torch.no_grad():
                                replacement.weight.copy_(first.weight.mean(dim=1, keepdim=True))
                        model.features[0][0] = replacement
                    feature_dim = model.classifier[-1].in_features
                    model.classifier = nn.Identity()
                    self._backbone = model
                except Exception:
                    if backend == "torchvision":
                        raise
            if self._backbone is None:
                self._backbone = _ImageBackbone(in_channels, feature_dim)
            self.head = nn.Linear(feature_dim, 1)

        def forward(self, value):
            features = self._backbone(value)
            if features.ndim > 2:
                features = torch.flatten(features, 1)
            return self.head(features).squeeze(-1)


    def crop_from_mask(images, masks, margin=0.2, output_size=None):
        """Create a differentiable batch ROI crop from binary masks."""
        if images.ndim != 4 or masks.ndim != 4:
            raise ValueError("images and masks must be NCHW tensors")
        output_size = output_size or tuple(images.shape[-2:])
        crops = []
        for image, mask in zip(images, masks):
            ys, xs = torch.where(mask[0] > 0.5)
            if len(xs) == 0:
                crop = image.unsqueeze(0)
            else:
                height, width = mask.shape[-2:]
                x0, x1 = int(xs.min()), int(xs.max()) + 1
                y0, y1 = int(ys.min()), int(ys.max()) + 1
                dx = int(round((x1 - x0) * margin))
                dy = int(round((y1 - y0) * margin))
                crop = image[:, max(0, y0 - dy):min(height, y1 + dy), max(0, x0 - dx):min(width, x1 + dx)].unsqueeze(0)
            crop = F.interpolate(crop, size=output_size, mode="bilinear", align_corners=False)
            crops.append(crop)
        return torch.cat(crops, dim=0)


    class DualViewClassifier(nn.Module):
        def __init__(self, in_channels=1, pretrained=False, feature_dim=128):
            super().__init__()
            self.full_backbone = _ImageBackbone(in_channels, feature_dim)
            self.roi_backbone = _ImageBackbone(in_channels, feature_dim)
            self.head = nn.Sequential(nn.Linear(feature_dim * 2, feature_dim), nn.ReLU(inplace=True), nn.Linear(feature_dim, 1))

        def forward(self, full_image, roi_image):
            full_feature = self.full_backbone(full_image)
            roi_feature = self.roi_backbone(roi_image)
            return self.head(torch.cat([full_feature, roi_feature], dim=1)).squeeze(-1)
else:
    class FullImageClassifier:  # pragma: no cover
        def __init__(self, *args, **kwargs):
            raise ImportError("PyTorch is required to construct the classification model")

    class DualViewClassifier(FullImageClassifier):
        pass

    def crop_from_mask(*args, **kwargs):  # pragma: no cover
        raise ImportError("PyTorch is required for ROI cropping")
