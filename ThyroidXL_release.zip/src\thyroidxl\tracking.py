from __future__ import annotations

import csv
import json
from pathlib import Path


EXPERIMENT_FIELDS = [
    "experiment_id", "task", "model", "encoder", "input_type", "input_size", "pretraining",
    "augmentation", "loss", "split", "seed", "dice", "iou", "hd95", "macro_f1",
    "balanced_accuracy", "accuracy", "auroc", "notes",
]


class ExperimentTracker:
    def __init__(self, csv_path):
        self.csv_path = Path(csv_path)
        self.csv_path.parent.mkdir(parents=True, exist_ok=True)

    def append(self, record):
        row = {field: record.get(field, "") for field in EXPERIMENT_FIELDS}
        exists = self.csv_path.exists()
        with self.csv_path.open("a", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=EXPERIMENT_FIELDS)
            if not exists:
                writer.writeheader()
            writer.writerow(row)
        return row

    def write_summary(self, summary, path):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
        return path
