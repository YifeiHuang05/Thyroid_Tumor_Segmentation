from __future__ import annotations

import json
from pathlib import Path


def load_config(path):
    path = Path(path)
    if path.suffix.lower() in (".yaml", ".yml"):
        import yaml
        return yaml.safe_load(path.read_text(encoding="utf-8"))
    return json.loads(path.read_text(encoding="utf-8"))


def save_config(config, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.suffix.lower() in (".yaml", ".yml"):
        import yaml
        path.write_text(yaml.safe_dump(config, sort_keys=False), encoding="utf-8")
    else:
        path.write_text(json.dumps(config, indent=2, ensure_ascii=False), encoding="utf-8")
    return path
