from __future__ import annotations

from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]


def remote_layout(root):
    """Return the canonical remote layout without creating files."""
    root = Path(root)
    return {
        "root": root,
        "raw": root / "data" / "raw" / "thyroidxl",
        "processed": root / "data" / "processed",
        "splits": root / "data" / "splits",
        "workspace": root / "workspace",
        "outputs": root / "outputs",
    }
