from __future__ import annotations

import csv
from collections import Counter
from pathlib import Path


def _rows(records):
    return [dict(record) if not isinstance(record, dict) else record.copy() for record in records]


def assert_no_group_overlap(rows, left="train", right="test", split_key="split", group_key="patient_id"):
    left_groups = {row[group_key] for row in rows if row.get(split_key) == left and row.get(group_key) is not None}
    right_groups = {row[group_key] for row in rows if row.get(split_key) == right and row.get(group_key) is not None}
    overlap = sorted(left_groups & right_groups)
    if overlap:
        raise ValueError("group leakage between %s and %s: %s" % (left, right, overlap[:10]))
    return True


def group_train_validation(records, validation_fraction=0.2, seed=20260811, group_key="patient_id", label_key="task_c_label"):
    """Deterministic group-safe split; stratification is best effort when sklearn supports it."""
    rows = _rows(records)
    if not rows:
        return [], []
    groups = sorted({row.get(group_key) for row in rows if row.get(group_key) is not None})
    if len(groups) < 2:
        raise ValueError("at least two groups are required")
    try:
        from sklearn.model_selection import GroupShuffleSplit
        import numpy as np
        indices = np.arange(len(rows))
        labels = [row.get(label_key) for row in rows]
        splitter = GroupShuffleSplit(n_splits=1, test_size=validation_fraction, random_state=seed)
        train_idx, val_idx = next(splitter.split(indices, labels, groups=[row.get(group_key) for row in rows]))
        train = [rows[i] for i in train_idx]
        val = [rows[i] for i in val_idx]
    except ImportError:
        import random
        rng = random.Random(seed)
        shuffled = list(groups)
        rng.shuffle(shuffled)
        cut = max(1, int(round(len(shuffled) * validation_fraction)))
        val_groups = set(shuffled[:cut])
        val = [row for row in rows if row.get(group_key) in val_groups]
        train = [row for row in rows if row.get(group_key) not in val_groups]
    _assert_disjoint(train, val, group_key)
    return train, val


def _assert_disjoint(left, right, group_key):
    overlap = {row.get(group_key) for row in left} & {row.get(group_key) for row in right}
    if overlap:
        raise ValueError("group leakage in internal split: %s" % sorted(overlap)[:10])


def write_split_manifest(rows, path):
    rows = _rows(rows)
    if not rows:
        raise ValueError("cannot write an empty split manifest")
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = list(rows[0].keys())
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    return path


def read_split_manifest(path):
    with Path(path).open("r", newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def summarize_split(rows, split_key="split", label_key="task_c_label", group_key="patient_id"):
    rows = _rows(rows)
    result = {}
    for split in sorted({row.get(split_key) for row in rows}):
        subset = [row for row in rows if row.get(split_key) == split]
        labels = Counter(row.get(label_key) for row in subset if row.get(label_key) not in (None, "", "nan"))
        result[split] = {"rows": len(subset), "groups": len({row.get(group_key) for row in subset}), "labels": dict(labels)}
    return result


def grouped_folds(records, n_splits=5, seed=20260811, group_key="patient_id", label_key="task_c_label"):
    """Yield leakage-safe folds, preferring StratifiedGroupKFold when available."""
    rows = _rows(records)
    if len({row.get(group_key) for row in rows}) < n_splits:
        raise ValueError("number of groups is smaller than n_splits")
    groups = [row.get(group_key) for row in rows]
    labels = [row.get(label_key, "") for row in rows]
    indices = list(range(len(rows)))
    try:
        from sklearn.model_selection import StratifiedGroupKFold
        import numpy as np
        splitter = StratifiedGroupKFold(n_splits=n_splits, shuffle=True, random_state=seed)
        folds = splitter.split(np.zeros(len(rows)), labels, groups)
    except (ImportError, AttributeError):
        from sklearn.model_selection import GroupKFold
        folds = GroupKFold(n_splits=n_splits).split(indices, labels, groups)
    for fold, (train_indices, val_indices) in enumerate(folds):
        train = [rows[int(i)] for i in train_indices]
        val = [rows[int(i)] for i in val_indices]
        _assert_disjoint(train, val, group_key)
        yield fold, train, val
