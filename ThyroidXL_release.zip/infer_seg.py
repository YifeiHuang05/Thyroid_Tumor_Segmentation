"""Standalone Task A inference: input PNG/JPG -> binary PNG mask."""
import argparse, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import numpy as np
from PIL import Image
import torch
from thyroidxl.models import UNetPlusPlusBaseline
from thyroidxl.data.transforms import PairedResizePad

def main():
    p=argparse.ArgumentParser(); p.add_argument('--input',required=True); p.add_argument('--output',required=True)
    p.add_argument('--weights',default=str(Path(__file__).parent/'weights/task_a_unetpp.pt')); p.add_argument('--size',type=int,default=128); p.add_argument('--threshold',type=float,default=.5)
    a=p.parse_args(); src=Image.open(a.input).convert('L'); t=PairedResizePad((a.size,a.size)); x,_=t(src,None); x=x.unsqueeze(0) if x.ndim==3 else x
    m=UNetPlusPlusBaseline(in_channels=1,classes=1,encoder_name='efficientnet-b3',pretrained=False,backend='fallback'); s=torch.load(a.weights,map_location='cpu'); m.load_state_dict(s.get('model',s)); m.eval()
    with torch.no_grad(): y=(torch.sigmoid(m(x))>a.threshold).byte()[0,0].numpy()*255
    out=Image.fromarray(y.astype(np.uint8)).resize(src.size,Image.Resampling.NEAREST); Path(a.output).parent.mkdir(parents=True,exist_ok=True); out.save(a.output)
if __name__=='__main__': main()
