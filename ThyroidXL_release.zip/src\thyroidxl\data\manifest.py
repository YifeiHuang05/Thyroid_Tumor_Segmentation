from __future__ import annotations

import csv
from pathlib import Path
from typing import Dict, Iterable, Iterator, List, NamedTuple, Optional, Sequence, Set


class ManifestSample(NamedTuple):
    image_id: str
    split: str
    image_path: str
    mask_path: Optional[str]
    label_path: Optional[str]
    original_label_path: Optional[str]
    patient_id: Optional[str]


class DatasetManifest:
    """Filesystem manifest builder; it never mutates raw data."""

    def __init__(self, root):
        self.root = Path(root)

    @staticmethod
    def patient_from_stem(stem):
        return stem.split("_", 1)[0] if "_" in stem else stem

    def _files(self, split, folder, suffix=None):
        path = self.root / split / folder
        if not path.exists():
            return {}
        files = path.glob("*" if suffix is None else "*" + suffix)
        return {p.stem: p for p in files if p.is_file()}

    def samples(self, split):
        images = self._files(split, "images", ".png")
        masks = self._files(split, "masks", ".png")
        labels = self._files(split, "labels", ".txt")
        originals = self._files(split, "labels_orig", ".json")
        for image_id in sorted(images):
            yield ManifestSample(
                image_id=image_id,
                split=split,
                image_path=str(images[image_id]),
                mask_path=str(masks[image_id]) if image_id in masks else None,
                label_path=str(labels[image_id]) if image_id in labels else None,
                original_label_path=str(originals[image_id]) if image_id in originals else None,
                patient_id=self.patient_from_stem(image_id),
            )

    def all_samples(self, splits=("train", "test")):
        for split in splits:
            for sample in self.samples(split):
                yield sample

    def split_summary(self, split):
        rows = list(self.samples(split))
        return {
            "split": split,
            "images": len(rows),
            "masks": sum(row.mask_path is not None for row in rows),
            "labels": sum(row.label_path is not None for row in rows),
            "original_labels": sum(row.original_label_path is not None for row in rows),
            "patients_from_filename": len({r.patient_id for r in rows if r.patient_id}),
            "missing_masks": [r.image_id for r in rows if r.mask_path is None],
            "missing_labels": [r.image_id for r in rows if r.label_path is None],
        }

    def train_test_patient_overlap(self):
        train = {r.patient_id for r in self.samples("train") if r.patient_id}
        test = {r.patient_id for r in self.samples("test") if r.patient_id}
        return sorted(train & test)

    def official_patient_lists(self):
        result = {}
        for split in ("train", "test"):
            path = self.root / "stats" / (split + "_patients.txt")
            if not path.exists():
                result[split] = None
                continue
            values = []
            for line in path.read_text(encoding="utf-8").splitlines():
                value = line.strip()
                if value:
                    values.append(value.split()[0])
            result[split] = sorted(set(values))
        return result

    def write_csv(self, path, splits=("train", "test")):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        fields = ManifestSample._fields
        with path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.writer(handle)
            writer.writerow(fields)
            writer.writerows(self.all_samples(splits))
        return path
