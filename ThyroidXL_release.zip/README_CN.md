# ThyroidXL 推理发布包

本包提供当前项目的 Task A 结节分割推理代码和最佳 U-Net++ 权重。分类权重与比赛五任务数据口径仍在统一 manifest 后重新训练，暂不作为最终提交模型发布。

## 安装

推荐 Python 3.10/3.11：

```bash
conda env create -f environment.yml
conda activate thyroidxl-inference
# 或 pip install -r requirements.txt
```

## 权重

权重位于 `weights/task_a_unetpp.pt`，为 128×128 输入的 U-Net++ baseline。CPU 可运行；GPU 可选，建议 NVIDIA GPU、CUDA 11.8+，显存 4 GB 以上。

## 推理

```bash
python infer_seg.py --input sample.png --output mask.png
```

参数：`--size` 默认 128，`--threshold` 默认 0.5，`--weights` 可替换权重。

输入为单张 PNG/JPG 超声图像；输出为与原图尺寸相同的单通道二值 PNG，病灶区域为 255，背景为 0。

## 复现说明

该推理脚本使用项目根目录的 `src/thyroidxl` 模块。若将发布包单独复制到其他目录，请同时保留同级的 `src/` 目录，或从项目根目录执行命令。

