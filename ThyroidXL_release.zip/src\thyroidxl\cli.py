from __future__ import annotations

import argparse
import json
from pathlib import Path

from .data.audit import audit_manifest, save_audit_report
from .data.manifest import DatasetManifest
from .data.gate import require_data_gate
from .data.splits import group_train_validation, write_split_manifest


def build_parser():
    parser = argparse.ArgumentParser(prog="thyroidxl")
    sub = parser.add_subparsers(dest="command", required=True)
    audit = sub.add_parser("audit", help="audit filesystem layout and optional content")
    audit.add_argument("--root", required=True)
    audit.add_argument("--output", required=True)
    audit.add_argument("--decode", action="store_true")
    manifest = sub.add_parser("manifest", help="write a local manifest")
    manifest.add_argument("--root", required=True)
    manifest.add_argument("--output", required=True)
    split = sub.add_parser("split", help="make a patient-grouped internal split")
    split.add_argument("--manifest", required=True)
    split.add_argument("--train-output", required=True)
    split.add_argument("--val-output", required=True)
    split.add_argument("--fraction", type=float, default=0.2)
    train = sub.add_parser("train", help="training entry-point guarded by DATA GATE")
    train.add_argument("--audit-report", required=True)
    train.add_argument("--allow-training", action="store_true")
    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)
    if args.command == "audit":
        report = audit_manifest(args.root, decode_content=args.decode)
        save_audit_report(report, args.output)
        print(json.dumps(report, indent=2, ensure_ascii=False))
        return 0
    if args.command == "manifest":
        path = DatasetManifest(args.root).write_csv(args.output)
        print(path)
        return 0
    if args.command == "split":
        import csv
        with Path(args.manifest).open("r", newline="", encoding="utf-8") as handle:
            rows = list(csv.DictReader(handle))
        train, val = group_train_validation(rows, validation_fraction=args.fraction)
        for row in train:
            row["split"] = "train_internal"
        for row in val:
            row["split"] = "val_internal"
        write_split_manifest(train, args.train_output)
        write_split_manifest(val, args.val_output)
        return 0
    if args.command == "train":
        from .training import train_guard
        train_guard(args.audit_report, allow_training=args.allow_training)
        raise RuntimeError("training implementation is intentionally not invoked by the P0 CLI")
    return 1
