from __future__ import annotations

from pathlib import Path


class ThyroidXLDataset:
    """Small map-style dataset for segmentation or classification records.

    Records must come from an audited manifest. Task C labels are consumed only
    from an explicit ``task_c_label`` field produced by the approved mapping.
    """

    def __init__(self, records, task="task_a", transform=None, image_mode="L"):
        self.records = list(records)
        self.task = task
        self.transform = transform
        self.image_mode = image_mode
        if task not in ("task_a", "task_c", "task_b_fnac", "task_d_bm", "task_e_tirads"):
            raise ValueError("unknown task: %s" % task)

    def __len__(self):
        return len(self.records)

    def _load_image(self, path):
        from PIL import Image
        import numpy as np
        image = Image.open(path).convert(self.image_mode)
        return image

    def __getitem__(self, index):
        record = self.records[index]
        image = self._load_image(record["image_path"] if isinstance(record, dict) else record.image_path)
        mask_path = record.get("mask_path") if isinstance(record, dict) else record.mask_path
        mask = self._load_image(mask_path) if self.task == "task_a" and mask_path else None
        if self.transform is not None:
            image, mask = self.transform(image, mask)
        result = {"image": image, "image_id": record.get("image_id") if isinstance(record, dict) else record.image_id}
        # Patient identifiers are metadata only and are used for patient-level
        # aggregation during evaluation.  Keep them as strings so the default
        # PyTorch collator can handle every audited manifest row.
        patient_id = record.get("patient_id", "") if isinstance(record, dict) else getattr(record, "patient_id", "")
        result["patient_id"] = "" if patient_id is None else str(patient_id)
        if self.task == "task_a":
            if mask is None:
                raise ValueError("Task A sample has no mask: %s" % result["image_id"])
            result["mask"] = mask
            label = record.get("task_c_label") if isinstance(record, dict) else getattr(record, "task_c_label", None)
            if label in ("ptc", "non_ptc_pathology", 0, 1, "0", "1"):
                result["label"] = 1 if label in ("ptc", 1, "1") else 0
        else:
            field = {"task_c": "task_c_label", "task_b_fnac": "fnac_label",
                     "task_d_bm": "benign_malignant_label", "task_e_tirads": "tirads_label"}[self.task]
            label = record.get(field) if isinstance(record, dict) else getattr(record, field, None)
            if label in (None, ""):
                raise ValueError("%s sample has no approved label: %s" % (self.task, result["image_id"]))
            if self.task == "task_c":
                result["label"] = 1 if label in ("ptc", 1, "1") else 0
            else:
                result["label"] = int(label)
            return result
        return result
