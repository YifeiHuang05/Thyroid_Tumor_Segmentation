from __future__ import annotations

import json
from pathlib import Path


REQUIRED_FIELDS = (
    "official_split_verified",
    "patient_grouping_verified",
    "lesion_grouping_verified",
    "task_c_mapping_verified",
    "task_a_content_verified",
    "train_val_leakage_verified",
)


def data_gate_status(report_path):
    path = Path(report_path)
    if not path.exists():
        return False, "audit report is missing"
    payload = json.loads(path.read_text(encoding="utf-8"))
    if payload.get("data_gate", {}).get("passed") is True:
        return True, "passed"
    gate = payload.get("data_gate", {})
    missing = [field for field in REQUIRED_FIELDS if gate.get(field) is not True]
    return False, "DATA GATE incomplete: " + ", ".join(missing or [gate.get("reason", "unknown reason")])


def require_data_gate(report_path):
    passed, reason = data_gate_status(report_path)
    if not passed:
        raise RuntimeError(reason)
