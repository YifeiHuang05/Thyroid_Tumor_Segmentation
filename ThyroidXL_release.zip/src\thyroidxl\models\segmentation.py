from __future__ import annotations


try:
    import torch
    from torch import nn
except ImportError:  # pragma: no cover - exercised only on non-training environments
    torch = None
    nn = None


if nn is not None:
    class _ConvBlock(nn.Module):
        def __init__(self, in_channels, out_channels):
            super().__init__()
            self.block = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, 3, padding=1, bias=False),
                nn.BatchNorm2d(out_channels),
                nn.ReLU(inplace=True),
                nn.Conv2d(out_channels, out_channels, 3, padding=1, bias=False),
                nn.BatchNorm2d(out_channels),
                nn.ReLU(inplace=True),
            )

        def forward(self, value):
            return self.block(value)


    class UNetPlusPlusBaseline(nn.Module):
        """Small dependency-free U-Net++-style baseline.

        When segmentation_models_pytorch is installed, ``backend='smp'`` can be
        selected to use its canonical U-Net++ EfficientNet-B3 implementation.
        The default fallback keeps construction and synthetic tests offline.
        """

        def __init__(self, in_channels=1, classes=1, encoder_name="efficientnet-b3", backend="auto", pretrained=False):
            super().__init__()
            self.encoder_name = encoder_name
            self.backend = backend
            self._smp = None
            if backend in ("auto", "smp"):
                try:
                    import segmentation_models_pytorch as smp
                    encoder_weights = "imagenet" if pretrained else None
                    self._smp = smp.UnetPlusPlus(
                        encoder_name=encoder_name,
                        encoder_weights=encoder_weights,
                        in_channels=in_channels,
                        classes=classes,
                    )
                except Exception:
                    if backend == "smp":
                        raise
            if self._smp is None:
                self.enc0 = _ConvBlock(in_channels, 32)
                self.enc1 = _ConvBlock(32, 64)
                self.enc2 = _ConvBlock(64, 128)
                self.pool = nn.MaxPool2d(2)
                self.up1 = nn.ConvTranspose2d(128, 64, 2, stride=2)
                self.dec1 = _ConvBlock(128, 64)
                self.up0 = nn.ConvTranspose2d(64, 32, 2, stride=2)
                self.dec0 = _ConvBlock(64, 32)
                self.head = nn.Conv2d(32, classes, 1)

        def forward(self, value):
            if self._smp is not None:
                return self._smp(value)
            x0 = self.enc0(value)
            x1 = self.enc1(self.pool(x0))
            x2 = self.enc2(self.pool(x1))
            y1 = self.dec1(torch.cat([self.up1(x2), x1], dim=1))
            y0 = self.dec0(torch.cat([self.up0(y1), x0], dim=1))
            return self.head(y0)


    class DeepLabV3Baseline(nn.Module):
        """DeepLabV3-style semantic segmentation baseline.

        Uses torchvision's ResNet-50 DeepLabV3 when available and a small
        dependency-free dilated-convolution fallback otherwise.
        """
        def __init__(self, in_channels=1, classes=1, pretrained=False, backend="auto"):
            super().__init__()
            self.backend = backend
            self._model = None
            if backend in ("auto", "torchvision"):
                try:
                    from torchvision.models.segmentation import deeplabv3_resnet50
                    model = deeplabv3_resnet50(weights=None, weights_backbone=None, num_classes=classes)
                    if in_channels != 3:
                        first = model.backbone.conv1
                        replacement = nn.Conv2d(in_channels, first.out_channels, first.kernel_size, first.stride, first.padding, bias=False)
                        model.backbone.conv1 = replacement
                    self._model = model
                except Exception:
                    if backend == "torchvision":
                        raise
            if self._model is None:
                self.stem = nn.Sequential(
                    nn.Conv2d(in_channels, 32, 3, stride=2, padding=1), nn.BatchNorm2d(32), nn.ReLU(inplace=True),
                    nn.Conv2d(32, 64, 3, stride=2, padding=1), nn.BatchNorm2d(64), nn.ReLU(inplace=True),
                )
                self.aspp = nn.Sequential(
                    nn.Conv2d(64, 128, 3, padding=6, dilation=6), nn.BatchNorm2d(128), nn.ReLU(inplace=True),
                    nn.Conv2d(128, 128, 3, padding=12, dilation=12), nn.BatchNorm2d(128), nn.ReLU(inplace=True),
                    nn.Conv2d(128, classes, 1),
                )

        def forward(self, value):
            import torch.nn.functional as F
            if self._model is not None:
                return self._model(value)["out"]
            size = value.shape[-2:]
            return F.interpolate(self.aspp(self.stem(value)), size=size, mode="bilinear", align_corners=False)


    class SegFormerLiteBaseline(nn.Module):
        """Small transformer encoder + dense decoder segmentation baseline."""
        def __init__(self, in_channels=1, classes=1, embed_dim=64, layers=2, heads=4):
            super().__init__()
            self.patch = nn.Conv2d(in_channels, embed_dim, kernel_size=4, stride=4)
            encoder_layer = nn.TransformerEncoderLayer(
                d_model=embed_dim, nhead=heads, dim_feedforward=embed_dim * 4,
                dropout=0.1, batch_first=True, norm_first=True, activation="gelu",
            )
            self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=layers)
            self.norm = nn.LayerNorm(embed_dim)
            self.decoder = nn.Sequential(
                nn.Conv2d(embed_dim, embed_dim // 2, 3, padding=1), nn.GELU(),
                nn.Conv2d(embed_dim // 2, classes, 1),
            )

        def forward(self, value):
            import torch.nn.functional as F
            size = value.shape[-2:]
            x = self.patch(value)
            height, width = x.shape[-2:]
            tokens = x.flatten(2).transpose(1, 2)
            tokens = self.norm(self.encoder(tokens))
            x = tokens.transpose(1, 2).reshape(value.shape[0], -1, height, width)
            return F.interpolate(self.decoder(x), size=size, mode="bilinear", align_corners=False)
else:
    class UNetPlusPlusBaseline:  # pragma: no cover
        def __init__(self, *args, **kwargs):
            raise ImportError("PyTorch is required to construct the segmentation model")
