from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, NamedTuple, Optional, Sequence


class MappingRule(NamedTuple):
    raw_value: str
    eligible: bool
    label: Optional[str]
    reason: str = ""


class TaskCMapping:
    """Explicit, auditable raw-value mapping. No medical defaults are assumed."""

    VALID_LABELS = ("ptc", "non_ptc_pathology")

    def __init__(self, rules=()):
        self.rules = {str(rule.raw_value): rule for rule in rules}

    @classmethod
    def from_json(cls, path):
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        rules = []
        for item in payload.get("rules", payload if isinstance(payload, list) else []):
            label = item.get("label")
            if label not in cls.VALID_LABELS and label is not None:
                raise ValueError("invalid Task C label: %r" % label)
            rules.append(MappingRule(str(item["raw_value"]), bool(item["eligible"]), label, item.get("reason", "")))
        return cls(rules)

    def resolve(self, raw_value):
        rule = self.rules.get(str(raw_value))
        if rule is None:
            return None, "unmapped_raw_value"
        if not rule.eligible:
            return None, rule.reason or "excluded_by_mapping"
        if rule.label not in self.VALID_LABELS:
            return None, "eligible_rule_has_no_valid_label"
        return rule.label, "eligible"

    def to_dict(self):
        return {"rules": [rule._asdict() for rule in self.rules.values()]}


class MetadataResolver:
    def __init__(self, metadata_path=None):
        self.metadata_path = Path(metadata_path) if metadata_path else None
        self.records = {}

    def load(self):
        if self.metadata_path is None:
            raise ValueError("metadata_path is required")
        payload = json.loads(self.metadata_path.read_text(encoding="utf-8"))
        if isinstance(payload, dict):
            self.records = payload
        elif isinstance(payload, list):
            self.records = {str(i): value for i, value in enumerate(payload)}
        else:
            raise ValueError("metadata root must be an object or list")
        return self.records

    def keys(self):
        return sorted(self.records)

    def values_for_field(self, field):
        values = []
        for record in self.records.values():
            if isinstance(record, Mapping) and field in record:
                values.append(record[field])
        return values

    def key_profile(self):
        profile = {}
        for record in self.records.values():
            if not isinstance(record, Mapping):
                continue
            for key, value in record.items():
                info = profile.setdefault(key, {"count": 0, "types": set()})
                info["count"] += 1
                info["types"].add(type(value).__name__)
        return {key: {"count": value["count"], "types": sorted(value["types"])} for key, value in profile.items()}


def apply_task_c_mapping(records, raw_field, mapping, id_field="image_id"):
    """Attach an approved Task C label and return rows plus aggregate decisions."""
    rows = []
    counts = {"ptc": 0, "non_ptc_pathology": 0, "excluded": 0, "reasons": {}}
    for record in records:
        row = dict(record)
        raw_value = row.get(raw_field)
        if raw_value is None or raw_value == "":
            label, reason = None, "missing_metadata"
        else:
            label, reason = mapping.resolve(raw_value)
        row["task_c_raw_value"] = raw_value
        row["task_c_label"] = label
        row["task_c_eligible"] = label is not None
        row["task_c_exclusion_reason"] = "" if label is not None else reason
        rows.append(row)
        if label in ("ptc", "non_ptc_pathology"):
            counts[label] += 1
        else:
            counts["excluded"] += 1
            counts["reasons"][reason] = counts["reasons"].get(reason, 0) + 1
    return rows, counts
